import os
import cv2
import joblib
import numpy as np
import tensorflow as tf
from flask import Flask, request, render_template, url_for
from PIL import Image
import io

app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# --- Blok Memuat Model (Tidak berubah) ---
try:
    base_model = tf.keras.applications.ResNet50(weights='imagenet', include_top=False, pooling='avg', input_shape=(128, 128, 3))
    model_pipeline = joblib.load('model/parkinson_classifier.pkl')
    scaler = model_pipeline['scaler']
    pca = model_pipeline['pca']
    model = model_pipeline['model']
    print("✅ Model berhasil dimuat.")
except Exception as e:
    print(f"❌ Terjadi kesalahan saat memuat model: {e}")
    base_model = model = scaler = pca = None
# Kode BARU
CLASS_NAMES = {
    0: "Kontrol (Sehat)",
    1: "Stadium Awal (Ringan)",
    2: "Stadium Menengah (Sedang)",
    3: "Stadium Lanjut (Berat)"
}

def preprocess_image(image_bytes):
    img = Image.open(io.BytesIO(image_bytes)).convert('L')
    img_array = np.array(img)
    img_rgb = cv2.cvtColor(img_array, cv2.COLOR_GRAY2RGB)
    img_resized = cv2.resize(img_rgb, (128, 128))
    return img_resized
# --- Akhir Blok Memuat Model ---


# Rute BARU untuk Halaman Home
@app.route('/')
def home():
    """Menampilkan halaman utama yang berisi informasi."""
    return render_template('home.html')


# Rute BARU untuk Halaman Test/Prediksi
@app.route('/test', methods=['GET', 'POST'])
def test():
    """Menangani upload gambar dan menampilkan hasil prediksi."""
    prediction_text = None
    image_url = None
    error_text = None
    predicted_class_lower = None

    if request.method == 'POST':
        if 'file' not in request.files or request.files['file'].filename == '':
            error_text = "Proses Gagal: Anda belum memilih file gambar untuk diunggah."
            return render_template('index.html', error=error_text)
        
        file = request.files['file']

        if file and model is not None:
            try:
                filename = file.filename
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                image_url = url_for('static', filename='uploads/' + filename)
                
                file.seek(0)
                img_bytes = file.read()
                
                # --- Pipeline Prediksi (Tidak berubah) ---
                processed_img = preprocess_image(img_bytes)
                x = np.expand_dims(processed_img, axis=0)
                x = tf.keras.applications.resnet50.preprocess_input(x)
                cnn_features = base_model.predict(x)
                scaled_features = scaler.transform(cnn_features)
                pca_features = pca.transform(scaled_features)
                prediction = model.predict(pca_features)
                
                predicted_class = CLASS_NAMES.get(prediction[0], "Tidak Diketahui")
                prediction_text = f"Hasil Prediksi: {predicted_class}"
                # Variabel baru untuk logika di HTML
                predicted_class_lower = predicted_class.lower()

            except Exception as e:
                error_text = f"Terjadi kesalahan saat pemrosesan: {e}"

    # Mengarahkan ke index.html (halaman test) dan mengirimkan variabel
    return render_template('index.html', 
                           prediction=prediction_text, 
                           image_url=image_url, 
                           error=error_text,
                           result_class=predicted_class_lower)


if __name__ == '__main__':
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    app.run(debug=True)